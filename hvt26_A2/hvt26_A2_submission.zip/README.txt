CS430 - A2 - Sutherland-Hodgman polygon clipping

Language: Java 11 OS: macOS Mojave 10.14.16

Compile/Execution Notes:
The main() is located in Main.java.
To run simply use makefile and run CG_hw1 as a shell script and indicate output with >
Example: ./CG_hw2 > out.ps