public class Window {
    public int top;
    public int bottom;
    public int left;
    public int right;
    //https://www.tutorialspoint.com/get-jframe-window-size-information-in-java
    public Window(int a, int b, int c, int d){
        this.left = a;
        this.bottom = b;
        this.right = c;
        this.top =d;

    }

}